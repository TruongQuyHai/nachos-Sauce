#include "syscall.h"

int main()
{
  PrintNum(RandomNum());

  Halt();
}